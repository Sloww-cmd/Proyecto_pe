
package Plataforma;


public class Plataforma {
    
        double sueldoMensual;
        double agua;
        double luz;
        double internet;
        double cable;
        double alimentos;
        double escolaridad;
        double universidad;
        double serviciosDeStreaming;
        double otrosGastos;
        double otrosIngresos;

    public Plataforma(double sueldoMensual, double agua, 
            double luz, double internet, double cable,
            double alimentos, double escolaridad, 
            double universidad, double serviciosDeStreaming,
            double otrosGastos, double otrosIngresos) {
        
        this.sueldoMensual = sueldoMensual;
        this.agua = agua;
        this.luz = luz;
        this.internet = internet;
        this.cable = cable;
        this.alimentos = alimentos;
        this.escolaridad = escolaridad;
        this.universidad = universidad;
        this.serviciosDeStreaming = serviciosDeStreaming;
        this.otrosGastos = otrosGastos;
        this.otrosIngresos= otrosIngresos;
    }
    public double totalIngresos(){
        return sueldoMensual+otrosIngresos; 
    }
        
    public double totaldeGastos(){
        return agua+luz+cable+internet+alimentos+ escolaridad + universidad+serviciosDeStreaming;
    }
    
    public double BalanceMensual(){
        return  totalIngresos()-totaldeGastos();
    }
    
   public double porcentajeGatosIngresos(){
       return totaldeGastos()/totalIngresos() * 100;
   }
   
   public double porcentajedeAhorro(){
       return BalanceMensual()/totalIngresos() * 100;
       
   }
   
   public double porcentajeAgua(){
       return agua/totalIngresos() *100;
       
   }
   
   public double porcentajeLuz(){
       return luz/totalIngresos() *100;
       
   }
   public double porcentajeInternet(){
       return internet/totalIngresos() *100;
       
   }
   public double porcentajeCable(){
       return cable/totalIngresos() *100;
       
   }
   public double porcentajeAlimentos(){
       return alimentos/totalIngresos() *100;
       
   }
   public double porcentajeEscolaridad(){
       return escolaridad/totalIngresos() *100;
       
   }
   public double porcentajeUniversidad(){
       return universidad/totalIngresos() *100;
       
   }
   
   public double porcentajeServiciosStream(){
       return serviciosDeStreaming/totalIngresos() *100;
       
   }
   public double otroGasto(){
       return otrosGastos/totalIngresos() *100;
   }
   
}
