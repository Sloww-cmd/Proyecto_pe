
package Login;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexionBD {

    public static Connection obtenerConexion(){
        try {

            String url = "jdbc:mysql://localhost:3306/usuariosregistrados";
            String usuario = "root";
            String contrasena = "aren05guerra";

            return DriverManager.getConnection(url, usuario, contrasena);
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }
}
